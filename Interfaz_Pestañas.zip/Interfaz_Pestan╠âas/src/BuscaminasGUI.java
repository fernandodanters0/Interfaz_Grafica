import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class BuscaminasGUI extends JFrame implements ActionListener {

    private static final int FILAS = 9;
    private static final int COLUMNAS = 9;
    private static final int MINAS = 9;

    private JButton[][] botones = new JButton[FILAS][COLUMNAS];
    private char[][] tablero = new char[FILAS][COLUMNAS];
    private boolean[][] minas = new boolean[FILAS][COLUMNAS];

    public BuscaminasGUI() {
        getContentPane().setBackground(new Color( 0, 0, 139)); // Cambiar a tu color deseado
        inicializarTablero();
        colocarMinas();
        inicializarInterfaz();
    
        // Ajustar tamaño y posición de la ventana
        setSize(500, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    

    private void inicializarTablero() {
        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                tablero[i][j] = '-';
            }
        }
    }

    private void colocarMinas() {
        Random random = new Random();
        int minasColocadas = 0;

        while (minasColocadas < MINAS) {
            int fila = random.nextInt(FILAS);
            int columna = random.nextInt(COLUMNAS);

            if (!minas[fila][columna]) {
                minas[fila][columna] = true;
                minasColocadas++;
            }
        }
    }

    private void inicializarInterfaz() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Buscaminas");
        setLayout(new GridLayout(FILAS, COLUMNAS));

        //JPanel panelBotones = new JPanel(new GridLayout(FILAS, COLUMNAS));

        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                botones[i][j] = new JButton("");
                botones[i][j].setFont(new Font("Arial", Font.PLAIN, 20));
                botones[i][j].addActionListener(this);
                //panelBotones.add(botones[i][j]);
                add(botones[i][j]);
            }
        }

        //add(panelBotones, BorderLayout.CENTER);

        pack();
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton boton = (JButton) e.getSource();

        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                if (boton == botones[i][j]) {
                    if (minas[i][j]) {
                        JOptionPane.showMessageDialog(this, "¡Has perdido! Has encontrado una mina.");
                        int respuesta = JOptionPane.showConfirmDialog(this, "¿Quieres volver a jugar?",
                                "Reiniciar juego", JOptionPane.YES_NO_OPTION);
                        if (respuesta == JOptionPane.YES_OPTION) {
                            reiniciarJuego();
                        } else {
                            System.exit(0);
                        }
                    } else {
                        int minasCercanas = contarMinasCercanas(i, j);
                        tablero[i][j] = (char) (minasCercanas + '0');
                        boton.setText(String.valueOf(minasCercanas));

                        if (minasCercanas == 0) {
                            revelarCeldasCercanas(i, j);
                        }

                        if (esVictoria()) {
                            JOptionPane.showMessageDialog(this, "¡Has ganado! Has encontrado todas las minas.");
                            reiniciarJuego(); // Cambiado para reiniciar el juego
                        }
                    }
                }
            }
        }
    }

    private void reiniciarJuego() {
        // Reinicializar todo
        inicializarTablero();
        colocarMinas();

        // Reinicializar la interfaz gráfica
        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                botones[i][j].setText("");
                botones[i][j].setEnabled(true);
            }
        }
    }

    private int contarMinasCercanas(int fila, int columna) {
        int minasCercanas = 0;

        for (int i = fila - 1; i <= fila + 1; i++) {
            for (int j = columna - 1; j <= columna + 1; j++) {
                if (i >= 0 && i < FILAS && j >= 0 && j < COLUMNAS && minas[i][j]) {
                    minasCercanas++;
                }
            }
        }

        return minasCercanas;
    }

    private void revelarCeldasCercanas(int fila, int columna) {
        for (int i = fila - 1; i <= fila + 1; i++) {
            for (int j = columna - 1; j <= columna + 1; j++) {
                if (i >= 0 && i < FILAS && j >= 0 && j < COLUMNAS && tablero[i][j] == '-') {
                    int minasCercanas = contarMinasCercanas(i, j);
                    tablero[i][j] = (char) (minasCercanas + '0');
                    botones[i][j].setText(String.valueOf(minasCercanas));

                    if (minasCercanas == 0) {
                        revelarCeldasCercanas(i, j);
                    }
                }
            }
        }
    }

    private boolean esVictoria() {
        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                if (!minas[i][j] && tablero[i][j] == '-') {
                    return false;
                }
            }
        }

        return true;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(BuscaminasGUI::new);
    }
}
