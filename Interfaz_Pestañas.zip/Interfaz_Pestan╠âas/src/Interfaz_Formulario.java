
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.*;

public class Interfaz_Formulario extends JFrame implements ActionListener {

    private JTabbedPane tabbedPane;
    private JButton addButton, cleanButton, printButton;
    private JLabel label1, label2, label3, label4;
    private JTextField textfield1, textfield2, textfield3, textfield4;
    private JPanel panelRegistrar, panelConsulta, panelReporte;
    private DefaultTableModel tableModel;    // Datos almacenados
    private ArrayList<String> datosRegistrados = new ArrayList<>();

    public Interfaz_Formulario() {

        // Pestaña Registrar
        panelRegistrar = new JPanel();
        panelRegistrar.setLayout(null);
        panelRegistrar.setBackground(new Color(169, 223, 191));

        // Pestaña Consulta
        panelConsulta = new JPanel();
        panelConsulta.setLayout(new BorderLayout());
        panelConsulta.setBackground(new Color(233, 150, 122));
        //panelConsulta.setBackground(Color.LIGHT_GRAY); // Puedes elegir el color que prefieras

        // Pestaña Reporte
        panelReporte = new JPanel();
        panelReporte.setLayout(null);
        panelReporte.setBackground(new Color(133, 193, 233));

        // Dato1
        label1 = new JLabel("Nombre:");
        label1.setBounds(70, 10, 100, 30);
        panelRegistrar.add(label1);

        textfield1 = new JTextField();
        textfield1.setBounds(130, 17, 150, 20);
        panelRegistrar.add(textfield1);

        // 2do Dato
        label2 = new JLabel("Apellidos:");
        label2.setBounds(60, 48, 100, 30);
        panelRegistrar.add(label2);

        textfield2 = new JTextField();
        textfield2.setBounds(130, 55, 150, 20); // Ajuste las coordenadas y el tamaño
        panelRegistrar.add(textfield2);

        // 3er Dato
        label3 = new JLabel("Edad: ");
        label3.setBounds(70, 86, 100, 30);
        panelRegistrar.add(label3);

        textfield3 = new JTextField();
        textfield3.setBounds(130, 93, 150, 20);
        panelRegistrar.add(textfield3);

        // 4to Dato
        label4 = new JLabel("Color Favorito:");
        label4.setBounds(38, 124, 100, 30);
        panelRegistrar.add(label4);

        textfield4 = new JTextField();
        textfield4.setBounds(130, 131, 150, 20); // Ajuste las coordenadas y el tamaño
        panelRegistrar.add(textfield4);

        // Creamos el boton
        addButton = new JButton("Registrar");
        addButton.setBounds(100, 420, 100, 30); // Posicionado debajo del JTextArea
        panelRegistrar.add(addButton);
        addButton.addActionListener(this);

        // Boton Limpiar
        cleanButton = new JButton("Limpiar");
        cleanButton.setBounds(400, 420, 100, 30);
        panelRegistrar.add(cleanButton);

        // Pestaña Consulta
        String[] columnNames = { "Nombre", "Apellidos", "Edad", "Color Favorito" };
        tableModel = new DefaultTableModel(columnNames, 0);
        JTable dataTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(dataTable);
        panelConsulta.add(scrollPane, BorderLayout.CENTER);

        printButton = new JButton("Imprimir");
        printButton.setBounds(400, 420, 100, 30);
        panelReporte.add(printButton);

        cleanButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                actionPerformed2(e);
            }
        });

        // Creamos la pestaña de Registar
        tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Registrar", panelRegistrar);
        tabbedPane.addTab("Consulta", panelConsulta);
        tabbedPane.addTab("Reporte", panelReporte);
        add(tabbedPane);

        // AGREGAR IMAGEN
        // Cargar la imagen
        ImageIcon icono = new ImageIcon("/Users/dante/Downloads/java.jpg");

        // Crear un JLabel para la imagen
        /*
         * JLabel imagenLabel = new JLabel(icono);
         * imagenLabel.setBounds(150, 220, 300, 150);
         * panelRegistrar.add(imagenLabel);
         */

        printButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                generarPDF();
            }
        });

    }

    public void actionPerformed(ActionEvent e) {
        String newUser = textfield1.getText();
        String newApellido = textfield2.getText();
        String newEdad = textfield3.getText();
        String newColor = textfield4.getText();

        int confirm = JOptionPane.showConfirmDialog(this, "¿Desea registrar la información?");

        if (confirm == JOptionPane.YES_OPTION) {
            String[] rowData = { newUser, newApellido, newEdad, newColor };
            tableModel.addRow(rowData);
        }

        textfield1.setText("");
        textfield2.setText("");
        textfield3.setText("");
        textfield4.setText("");
    }

    // Metodo de Boton limpiar
    public void actionPerformed2(ActionEvent e) {
        textfield1.setText("");
        textfield2.setText("");
        textfield3.setText("");
        textfield4.setText("");
        tableModel.setRowCount(0); // Limpiar la tabla
    }

    public void generarPDF() {
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream("datos.pdf"));
            document.open();

            for (String dato : datosRegistrados) {
                document.add(new Paragraph(dato));
            }

            document.close();
            System.out.println("El PDF se ha creado exitosamente.");
        } catch (DocumentException | FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Interfaz_Formulario nvi2 = new Interfaz_Formulario();
            nvi2.setBounds(0, 0, 600, 550);
            nvi2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            nvi2.setVisible(true);
            nvi2.setLocationRelativeTo(null);
        });
    }

}
